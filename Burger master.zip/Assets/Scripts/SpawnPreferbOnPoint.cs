using System.Collections.Generic;
using UnityEngine;

public class SpawnPrefabOnPoints : MonoBehaviour
{
    public GameObject prefabToSpawn; // 생성할 프리팹
    public List<Transform> spawnPoints; // 빈 오브젝트들의 위치를 담은 리스트
    public float checkRadius = 0.5f; // 콜라이더 감지 반경

    void OnMouseDown()
    {
        foreach (Transform point in spawnPoints)
        {
            // 해당 위치에 콜라이더가 없을 때만 프리팹을 생성
            if (IsSpaceEmpty(point.position))
            {
                Instantiate(prefabToSpawn, point.position, Quaternion.identity);
            }
        }
    }

    // 지정된 위치에 콜라이더가 없는지 확인하는 메서드
    bool IsSpaceEmpty(Vector3 position)
    {
        Collider[] colliders = Physics.OverlapSphere(position, checkRadius);
        return colliders.Length == 0; // 감지된 콜라이더가 없으면 true 반환
    }
}
